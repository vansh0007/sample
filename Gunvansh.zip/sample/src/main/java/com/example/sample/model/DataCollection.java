package com.example.sample.model;

import jakarta.persistence.*;
import java.sql.Timestamp;

import jakarta.transaction.Transactional;
import lombok.*;
import org.hibernate.annotations.Where;


@Entity
@Table(name = "data_collections")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DataCollection {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "created_on", nullable = false, updatable = false)
    private Timestamp createdOn;

    @Column(name = "updated_on")
    private Timestamp updatedOn;

    @ManyToOne
    @JoinColumn(name = "file_id_orders", nullable = false)
    private DataFile fileOrders;

    @ManyToOne
    @JoinColumn(name = "file_id_assets", nullable = false)
    private DataFile fileAssets;

    @ManyToOne
    @JoinColumn(name = "file_id_inventory", nullable = false)
    private DataFile fileInventory;

    @Column(nullable = false)
    private String status;

    private String tag;

    @Column(length = 1000)
    private String note;

    @Column(name = "is_deleted")
    @Where(clause = "is_deleted = false")
    private boolean deleted; // Soft delete flag

    @PrePersist
    protected void onCreate() {
        createdOn = new Timestamp(System.currentTimeMillis());
        if (fileOrders == null) {
            throw new IllegalArgumentException("fileOrders cannot be null");
        }
        if (fileAssets == null) {
            throw new IllegalArgumentException("fileAssets cannot be null");
        }
        if (fileInventory == null) {
            throw new IllegalArgumentException("fileInventory cannot be null");
        }
        if (status == null) {
            throw new IllegalArgumentException("status cannot be null");
        }
    }

    @Transactional
    @PreUpdate
    protected void onUpdate() {
        updatedOn = new Timestamp(System.currentTimeMillis());
    }
}
