package com.example.sample.repository;


import com.example.sample.model.DataFile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DataFileRepository extends JpaRepository<DataFile, Long> {
}
