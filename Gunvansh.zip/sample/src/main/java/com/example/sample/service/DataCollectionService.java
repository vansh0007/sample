package com.example.sample.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.example.sample.model.DataCollection;
import com.example.sample.model.DataFile;
import com.example.sample.repository.DataCollectionRepository;
import com.example.sample.repository.DataFileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;




@Service
public class DataCollectionService {

    private final DataCollectionRepository dataCollectionRepository;
    private final DataFileRepository dataFileRepository;
    private final Logger logger = LoggerFactory.getLogger(DataCollectionService.class);

    @Autowired
    public DataCollectionService(DataCollectionRepository dataCollectionRepository, DataFileRepository dataFileRepository) {
        this.dataCollectionRepository = dataCollectionRepository;
        this.dataFileRepository = dataFileRepository;
    }

    public DataCollection createDataCollection(DataCollection newDataCollection) {
        validateDataFiles(newDataCollection);
        return dataCollectionRepository.save(newDataCollection);
    }

    public DataCollection updateDataCollection(Long id, DataCollection updatedDataCollection) {
        validateDataFiles(updatedDataCollection);
        Optional<DataCollection> optionalDataCollection = dataCollectionRepository.findById(id);
        if (optionalDataCollection.isPresent()) {
            DataCollection dataCollection = optionalDataCollection.get();
            dataCollection.setCreatedOn(updatedDataCollection.getCreatedOn());
            dataCollection.setUpdatedOn(updatedDataCollection.getUpdatedOn());
            dataCollection.setFileOrders(updatedDataCollection.getFileOrders());
            dataCollection.setFileAssets(updatedDataCollection.getFileAssets());
            dataCollection.setFileInventory(updatedDataCollection.getFileInventory());
            dataCollection.setStatus(updatedDataCollection.getStatus());
            dataCollection.setTag(updatedDataCollection.getTag());
            dataCollection.setNote(updatedDataCollection.getNote());
            dataCollection.setDeleted(updatedDataCollection.isDeleted());
            return dataCollectionRepository.save(dataCollection);
        } else {
            throw new IllegalArgumentException("Data Collection with ID " + id + " does not exist.");
        }
    }

    public List<DataCollection> listDataCollectionsSortedBy(String sortBy) {
        List<DataCollection> dataCollections;
        Sort sort;
        if (sortBy != null) {
            sort = switch (sortBy.toLowerCase()) {
                case "created_on" -> Sort.by(Sort.Direction.DESC, "createdOn");
                case "updated_on" -> Sort.by(Sort.Direction.ASC, "updatedOn");
//                default -> {
//                    logger.warn("Invalid sortBy parameter. Defaulting to sorting by createdOn in ascending order.");
//                    sort = Sort.by(Sort.Direction.ASC, "createdOn");
//                }
                default -> throw new IllegalStateException("Unexpected value: " + sortBy.toLowerCase());
            };
            dataCollections = dataCollectionRepository.findAll(sort);
        } else {
            dataCollections = dataCollectionRepository.findAll();
        }
        return dataCollections;
    }

    public void deleteDataCollection(Long id) {
        if (dataCollectionRepository.existsById(id)) {
            dataCollectionRepository.deleteById(id);
        } else {
            throw new IllegalArgumentException("Data Collection with ID " + id + " does not exist.");
        }
    }

    private void validateDataFiles(DataCollection dataCollection) {
        if (dataCollection.getFileAssets() != null) {
            Long fileAssetId = dataCollection.getFileAssets().getId();
            logger.debug("DataFiles in the database: {}", dataFileRepository.findAll());
            Optional<DataFile> optionalDataFile = dataFileRepository.findById(fileAssetId);
            if (!optionalDataFile.isPresent()) {
                throw new IllegalArgumentException("Referenced DataFile with ID " + fileAssetId + " does not exist.");
            }
        }
    }

    public Optional<DataCollection> getDataCollectionById(Long id) {
        return dataCollectionRepository.findById(id);
    }

}
