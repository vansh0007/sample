package com.example.sample.controller;

import com.example.sample.model.DataCollection;
import com.example.sample.service.DataCollectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/data-collections")
public class DataCollectionController {
    private final DataCollectionService dataCollectionService;

    @Autowired
    public DataCollectionController(DataCollectionService dataCollectionService) {
        this.dataCollectionService = dataCollectionService;
    }

    // GET endpoint to list Data Collections with filtering and sorting
    @GetMapping
    public ResponseEntity<List<DataCollection>> listDataCollections(
            @RequestParam(required = false) String sortBy,
            @RequestParam(required = false) String filterByNoteContaining
    ) {
        List<DataCollection> dataCollections;

        // If sortBy parameter is provided, sort the list accordingly
        dataCollections = dataCollectionService.listDataCollectionsSortedBy(sortBy);


        // If filterByNoteContaining parameter is provided, filter the list by note containing the specified substring
        if (filterByNoteContaining != null && !filterByNoteContaining.isEmpty()) {
            dataCollections = dataCollections.stream()
                    .filter(dataCollection -> dataCollection.getNote() != null && dataCollection.getNote().contains(filterByNoteContaining))
                    .collect(Collectors.toList());
        }

        return ResponseEntity.ok(dataCollections);
    }

    // GET endpoint to retrieve a Data Collection by ID
    @GetMapping("/{id}")
    public ResponseEntity<DataCollection> getDataCollectionById(@PathVariable Long id) {
        return dataCollectionService.getDataCollectionById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // POST endpoint to create a new Data Collection
    @PostMapping
    public ResponseEntity<DataCollection> createDataCollection(@RequestBody DataCollection newDataCollection) {
        System.out.println(newDataCollection);
        DataCollection createdDataCollection = dataCollectionService.createDataCollection(newDataCollection);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdDataCollection);
    }

    // PUT endpoint to update an existing Data Collection
    @PutMapping("/{id}")
    public ResponseEntity<DataCollection> updateDataCollection(@PathVariable Long id, @RequestBody DataCollection updatedDataCollection) {
        DataCollection updatedData = dataCollectionService.updateDataCollection(id, updatedDataCollection);
        return ResponseEntity.ok(updatedData);
    }

     //DELETE endpoint to delete a Data Collection by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDataCollection(@PathVariable Long id) {
        dataCollectionService.deleteDataCollection(id);
        return ResponseEntity.noContent().build();
    }
}
