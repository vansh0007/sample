package com.example.sample.model;

import jakarta.persistence.*;
import lombok.Getter;
import org.jetbrains.annotations.NotNull;

import java.sql.Timestamp;

@Entity
@Table(name = "data_file")
public class DataFile {
    @Getter
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Column(name = "created_on", nullable = false)
    private Timestamp createdOn;

    @Column(name = "updated_on")
    private Timestamp updatedOn;

    @Column(name = "file_type", nullable = false)
    private String fileType;


    @Column(name = "validation_status", nullable = false)
    private String validationStatus;


    public DataFile(Long id, @NotNull Timestamp createdOn, String fileType, Timestamp updatedOn, String validationStatus) {
        this.id = id;
        this.createdOn = createdOn;
        this.fileType = fileType;
        this.updatedOn = updatedOn;
        this.validationStatus = validationStatus;
    }


    public DataFile() {

    }

}

