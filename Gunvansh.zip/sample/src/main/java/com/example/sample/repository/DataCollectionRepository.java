package com.example.sample.repository;

import com.example.sample.model.DataCollection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DataCollectionRepository extends JpaRepository<DataCollection, Long> {
}
