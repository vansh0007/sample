//
//
//import com.example.sample.model.DataCollection;
//import com.example.sample.model.DataFile;
//import com.example.sample.repository.DataCollectionRepository;
//import com.example.sample.repository.DataFileRepository;
//import com.example.sample.service.DataCollectionService;
//
//import org.junit.Test;
//import org.mockito.Mockito;
//import org.springframework.data.domain.Sort;
//
//import java.sql.Timestamp;
//import java.time.LocalDateTime;
//import java.util.Arrays;
//import java.util.List;
//import java.util.Optional;
//
//import static org.junit.Assert.*;
//
//public class DataCollectionServiceTest {
//    // createDataCollection method saves a new DataCollection with valid DataFiles
//    @Test
//    public void test_createDataCollection_validDataFiles() {
//        // Arrange
//        DataFile fileAssets = new DataFile(1L, new Timestamp(System.currentTimeMillis()), "fileType", null, "validationStatus");
//        DataCollection newDataCollection = new DataCollection(1L, new Timestamp(System.currentTimeMillis()), null, fileAssets, null, "status", "tag", "note", false);
//
//        // Act
//        DataCollection result = dataCollectionService.createDataCollection(newDataCollection);
//
//        // Assert
//        assertNotNull(result);
//        assertEquals(newDataCollection.getCreatedOn(), result.getCreatedOn());
//        assertEquals(newDataCollection.getFileAssets(), result.getFileAssets());
//        assertEquals(newDataCollection.getStatus(), result.getStatus());
//    }
//
//    // updateDataCollection method updates an existing DataCollection with valid DataFiles
//    @Test
//    public void test_update_data_collection_with_valid_data_files() {
//        // Create a new DataCollection
//        DataCollection newDataCollection = new DataCollection();
//        newDataCollection.setCreatedOn(new Timestamp(System.currentTimeMillis()));
//        newDataCollection.setUpdatedOn(null);
//        newDataCollection.setFileOrders(null);
//        newDataCollection.setFileAssets(null);
//        newDataCollection.setFileInventory(null);
//        newDataCollection.setStatus("status");
//        newDataCollection.setTag("tag");
//        newDataCollection.setNote("note");
//        newDataCollection.setDeleted(false);
//
//        // Save the new DataCollection
//        DataCollection savedDataCollection = dataCollectionService.createDataCollection(newDataCollection);
//
//        // Update the DataCollection with valid DataFiles
//        DataFile fileOrders = new DataFile();
//        fileOrders.setCreatedOn(new Timestamp(System.currentTimeMillis()));
//        fileOrders.setUpdatedOn(null);
//        fileOrders.setFileType("fileType");
//        fileOrders.setValidationStatus("validationStatus");
//        DataFile savedFileOrders = dataFileRepository.save(fileOrders);
//
//        DataFile fileAssets = new DataFile();
//        fileAssets.setCreatedOn(new Timestamp(System.currentTimeMillis()));
//        fileAssets.setUpdatedOn(null);
//        fileAssets.setFileType("fileType");
//        fileAssets.setValidationStatus("validationStatus");
//        DataFile savedFileAssets = dataFileRepository.save(fileAssets);
//
//        DataFile fileInventory = new DataFile();
//        fileInventory.setCreatedOn(new Timestamp(System.currentTimeMillis()));
//        fileInventory.setUpdatedOn(null);
//        fileInventory.setFileType("fileType");
//        fileInventory.setValidationStatus("validationStatus");
//        DataFile savedFileInventory = dataFileRepository.save(fileInventory);
//
//        savedDataCollection.setFileOrders(savedFileOrders);
//        savedDataCollection.setFileAssets(savedFileAssets);
//        savedDataCollection.setFileInventory(savedFileInventory);
//
//        DataCollection updatedDataCollection = dataCollectionService.updateDataCollection(savedDataCollection.getId(), savedDataCollection);
//
//        // Assert that the DataCollection is updated with valid DataFiles
//        assertEquals(savedDataCollection.getCreatedOn(), updatedDataCollection.getCreatedOn());
//        assertEquals(savedDataCollection.getUpdatedOn(), updatedDataCollection.getUpdatedOn());
//        assertEquals(savedDataCollection.getFileOrders(), updatedDataCollection.getFileOrders());
//        assertEquals(savedDataCollection.getFileAssets(), updatedDataCollection.getFileAssets());
//        assertEquals(savedDataCollection.getFileInventory(), updatedDataCollection.getFileInventory());
//        assertEquals(savedDataCollection.getStatus(), updatedDataCollection.getStatus());
//        assertEquals(savedDataCollection.getTag(), updatedDataCollection.getTag());
//        assertEquals(savedDataCollection.getNote(), updatedDataCollection.getNote());
//        assertEquals(savedDataCollection.isDeleted(), updatedDataCollection.isDeleted());
//    }
//
//    // listDataCollectionsSortedBy method returns a list of DataCollections sorted by createdOn or updatedOn
//    @Test
//    public void test_listDataCollectionsSortedBy() {
//        // Create test data
//        DataFile file1 = new DataFile(1L, new Timestamp(System.currentTimeMillis()), "type1", null, "status1");
//        DataFile file2 = new DataFile(2L, new Timestamp(System.currentTimeMillis()), "type2", null, "status2");
//        DataFile file3 = new DataFile(3L, new Timestamp(System.currentTimeMillis()), "type3", null, "status3");
//
//        DataCollection dataCollection1 = new DataCollection(1L, new Timestamp(System.currentTimeMillis()), null, null, null, "status1", null, null, false);
//        dataCollection1.setFileOrders(file1);
//        dataCollection1.setFileAssets(file2);
//        dataCollection1.setFileInventory(file3);
//
//        DataCollection dataCollection2 = new DataCollection(2L, new Timestamp(System.currentTimeMillis()), null, null, null, "status2", null, null, false);
//        dataCollection2.setFileOrders(file2);
//        dataCollection2.setFileAssets(file3);
//        dataCollection2.setFileInventory(file1);
//
//        List<DataCollection> expectedList = Arrays.asList(dataCollection1, dataCollection2);
//
//        // Mock the repository
//        DataCollectionRepository mockRepository = Mockito.mock(DataCollectionRepository.class);
//        Mockito.when(mockRepository.findAll(Mockito.any(Sort.class))).thenReturn(expectedList);
//
//        // Create the service instance with the mock repository
//        DataCollectionService dataCollectionService = new DataCollectionService(mockRepository, null);
//
//        // Call the method to be tested
//        List<DataCollection> resultList = dataCollectionService.listDataCollectionsSortedBy("created_on");
//
//        // Assert the result
//        assertEquals(expectedList, resultList);
//    }
//
//    // deleteDataCollection method deletes an existing DataCollection
//    @Test
//    public void test_delete_data_collection() {
//        // Create a new DataCollection
//        DataCollection newDataCollection = new DataCollection();
//        newDataCollection.setCreatedOn(new Timestamp(System.currentTimeMillis()));
//        newDataCollection.setFileOrders(new DataFile());
//        newDataCollection.setFileAssets(new DataFile());
//        newDataCollection.setFileInventory(new DataFile());
//        newDataCollection.setStatus("status");
//        newDataCollection.setTag("tag");
//        newDataCollection.setNote("note");
//        newDataCollection.setDeleted(false);
//
//        // Save the new DataCollection
//        DataCollection savedDataCollection = dataCollectionService.createDataCollection(newDataCollection);
//
//        // Delete the DataCollection
//        dataCollectionService.deleteDataCollection(savedDataCollection.getId());
//
//        // Verify that the DataCollection is deleted
//        Optional<DataCollection> deletedDataCollection = dataCollectionService.getDataCollectionById(savedDataCollection.getId());
//        assertFalse(deletedDataCollection.isPresent());
//    }
//
//    // createDataCollection method throws an exception if any of the required fields are null
//    @Test
//    public void test_createDataCollection_throwsExceptionIfRequiredFieldsAreNull() {
//        // Arrange
//        DataCollection newDataCollection = new DataCollection();
//
//        // Act and Assert
//        assertThrows(IllegalArgumentException.class, () -> dataCollectionService.createDataCollection(newDataCollection));
//    }
//
//    // updateDataCollection method throws an exception if the DataCollection with the given ID does not exist
//    @Test
//    public void test_updateDataCollection_DataCollectionNotExist() {
//        // Arrange
//        Long id = 1L;
//        DataCollection updatedDataCollection = new DataCollection();
//        updatedDataCollection.setId(id);
//
//        // Act and Assert
//        assertThrows(IllegalArgumentException.class, () -> {
//            dataCollectionService.updateDataCollection(id, updatedDataCollection);
//        });
//    }
//
//    // listDataCollectionsSortedBy method throws an exception if the sortBy parameter is not valid
//    @Test
//    public void test_listDataCollectionsSortedBy_invalidSortByParameter() {
//        // Arrange
//        DataCollectionRepository dataCollectionRepository = mock(DataCollectionRepository.class);
//        DataFileRepository dataFileRepository = mock(DataFileRepository.class);
//        DataCollectionService dataCollectionService = new DataCollectionService(dataCollectionRepository, dataFileRepository);
//
//        // Act and Assert
//        assertThrows(IllegalStateException.class, () -> {
//            dataCollectionService.listDataCollectionsSortedBy("invalid_sort_by");
//        });
//    }
//
//    // deleteDataCollection method throws an exception if the DataCollection with the given ID does not exist
//    @Test
//    public void test_deleteDataCollection_ThrowsExceptionIfDataCollectionDoesNotExist() {
//        // Arrange
//        Long id = 1L;
//        when(dataCollectionRepository.existsById(id)).thenReturn(false);
//
//        // Act and Assert
//        assertThrows(IllegalArgumentException.class, () -> dataCollectionService.deleteDataCollection(id));
//    }
//
//    // validateDataFiles method does not throw an exception if a referenced DataFile is null
//    @Test
//    public void test_validateDataFiles_noExceptionIfReferencedDataFileIsNull() {
//        // Create a new DataCollection with null fileAssets
//        DataCollection dataCollection = new DataCollection();
//        dataCollection.setFileAssets(null);
//
//        // Mock the behavior of dataFileRepository.findById() to return an empty Optional
//        when(dataFileRepository.findById(anyLong())).thenReturn(Optional.empty());
//
//        // Call the method under test
//        dataCollectionService.validateDataFiles(dataCollection);
//
//        // Verify that no exception is thrown
//        // If an exception is thrown, the test will fail
//    }
//
//    // validateDataFiles method throws an exception if a referenced DataFile does not exist
//    @Test
//    public void test_validateDataFiles_referencedDataFileDoesNotExist() {
//        // Create a new DataCollection with a referenced DataFile that does not exist
//        DataCollection dataCollection = new DataCollection();
//        DataFile fileAssets = new DataFile(1L, new Timestamp(System.currentTimeMillis()), "fileType", null, "validationStatus");
//        dataCollection.setFileAssets(fileAssets);
//
//        // Mock the behavior of the dataFileRepository.findById() method to return an empty Optional
//        when(dataFileRepository.findById(anyLong())).thenReturn(Optional.empty());
//
//        // Assert that an IllegalArgumentException is thrown when calling the validateDataFiles() method
//        assertThrows(IllegalArgumentException.class, () -> dataCollectionService.validateDataFiles(dataCollection));
//    }
//
//    // createDataCollection method throws an exception if any of the referenced DataFiles do not exist
//    @Test
//    public void test_createDataCollection_throwsExceptionIfReferencedDataFilesDoNotExist() {
//        // Create a new DataCollection object
//        DataCollection newDataCollection = new DataCollection();
//
//        // Set the fileAssets to a DataFile object with an ID that does not exist in the dataFileRepository
//        DataFile nonExistentDataFile = new DataFile(100L, new Timestamp(System.currentTimeMillis()), "csv", null, "valid");
//        newDataCollection.setFileAssets(nonExistentDataFile);
//
//        // Assert that an IllegalArgumentException is thrown when calling createDataCollection
//        assertThrows(IllegalArgumentException.class, () -> dataCollectionService.createDataCollection(newDataCollection));
//    }
//
//    // deleteDataCollection method does not delete the referenced DataFiles
//    @Test
//    public void test_deleteDataCollection_doesNotDeleteReferencedDataFiles() {
//        // Create a new DataFile
//        DataFile dataFile = new DataFile();
//        dataFile.setCreatedOn(new Timestamp(System.currentTimeMillis()));
//        dataFile.setFileType("csv");
//        dataFile.setValidationStatus("valid");
//        DataFile savedDataFile = dataFileRepository.save(dataFile);
//
//        // Create a new DataCollection with the created DataFile as the fileAssets
//        DataCollection dataCollection = new DataCollection();
//        dataCollection.setCreatedOn(new Timestamp(System.currentTimeMillis()));
//        dataCollection.setFileAssets(savedDataFile);
//        dataCollection.setStatus("active");
//        DataCollection savedDataCollection = dataCollectionRepository.save(dataCollection);
//
//        // Delete the DataCollection
//        dataCollectionService.deleteDataCollection(savedDataCollection.getId());
//
//        // Check if the DataFile still exists
//        Optional<DataFile> optionalDataFile = dataFileRepository.findById(savedDataFile.getId());
//        assertTrue(optionalDataFile.isPresent());
//    }
//
//    // validateDataFiles method throws an exception if a referenced DataFile is deleted
//    @Test
//    public void test_validateDataFiles_throwsExceptionIfReferencedDataFileIsDeleted() {
//        // Create a new DataCollection
//        DataCollection dataCollection = new DataCollection();
//
//        // Create a new DataFile
//        DataFile dataFile = new DataFile();
//        dataFile.setId(1L);
//
//        // Set the DataFile as the fileAssets in the DataCollection
//        dataCollection.setFileAssets(dataFile);
//
//        // Mock the behavior of the dataFileRepository.findById() method to return an empty Optional
//        when(dataFileRepository.findById(1L)).thenReturn(Optional.empty());
//
//        // Assert that calling the createDataCollection() method throws an IllegalArgumentException
//        assertThrows(IllegalArgumentException.class, () -> dataCollectionService.createDataCollection(dataCollection));
//    }
//
//    // updateDataCollection method does not update the createdOn field
//    @Test
//    public void test_updateDataCollection_doesNotUpdateCreatedOnField() {
//        // Create a new DataCollection object
//        DataCollection newDataCollection = new DataCollection();
//        newDataCollection.setCreatedOn(Timestamp.valueOf(LocalDateTime.now().minusDays(1)));
//        newDataCollection.setUpdatedOn(Timestamp.valueOf(LocalDateTime.now()));
//        newDataCollection.setFileOrders(new DataFile());
//        newDataCollection.setFileAssets(new DataFile());
//        newDataCollection.setFileInventory(new DataFile());
//        newDataCollection.setStatus("status");
//        newDataCollection.setTag("tag");
//        newDataCollection.setNote("note");
//        newDataCollection.setDeleted(false);
//
//        // Save the new DataCollection
//        DataCollection savedDataCollection = dataCollectionService.createDataCollection(newDataCollection);
//
//        // Update the DataCollection
//        DataCollection updatedDataCollection = new DataCollection();
//        updatedDataCollection.setId(savedDataCollection.getId());
//        updatedDataCollection.setCreatedOn(Timestamp.valueOf(LocalDateTime.now()));
//        updatedDataCollection.setUpdatedOn(Timestamp.valueOf(LocalDateTime.now()));
//        updatedDataCollection.setFileOrders(new DataFile());
//        updatedDataCollection.setFileAssets(new DataFile());
//        updatedDataCollection.setFileInventory(new DataFile());
//        updatedDataCollection.setStatus("updated status");
//        updatedDataCollection.setTag("updated tag");
//        updatedDataCollection.setNote("updated note");
//        updatedDataCollection.setDeleted(true);
//
//        // Call the updateDataCollection method
//        DataCollection result = dataCollectionService.updateDataCollection(savedDataCollection.getId(), updatedDataCollection);
//
//        // Assert that the createdOn field is not updated
//        assertEquals(savedDataCollection.getCreatedOn(), result.getCreatedOn());
//    }
//
//    // listDataCollectionsSortedBy method returns an empty list if there are no DataCollections
//    @Test
//    public void test_listDataCollectionsSortedBy_emptyList() {
//        // Arrange
//        List<DataCollection> expected = new ArrayList<>();
//        when(dataCollectionRepository.findAll()).thenReturn(expected);
//
//        // Act
//        List<DataCollection> actual = dataCollectionService.listDataCollectionsSortedBy(null);
//
//        // Assert
//        assertEquals(expected, actual);
//    }
//
//}